Why need to install display GPi Case patch for Retropie and Recalbox? 
Because Retropie and Recalbox system default display output is HDMI, GPi Case2 need to transfer display output to GPIO then can work correctly.

For Windows:
Install display patch for GPi Case
1.Copy CPi_Case2_patch_XXXsystem folder to SD root.
2.Enter CPi_Case2_patch_XXXsystem folder and run install_patch.bat
3.Patch done. SD card can be used for GPi Case2 cartridge.

Uninstall patch can transfer to HDMI output again
1.Enter GPi_Case2_patch_XXXsystem folder and run uninstall_patch.bat
-------------------------------------------------------------------------------
For MacOS:
1.Backup config.txt to safe place.
2.Copy /GPi_Case_patch_XXXsystem/patch_files/config.txt to SD card root.


Want to transfer to HDMI output again
1.Copy the backup config.txt to SD card root.
